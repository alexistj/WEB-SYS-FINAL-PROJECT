<?php 
  include('Messenger.php'); 
  include('functions.php'); 
?>


<?php

$whitelist = array('sender','receiver','message');

$table = 'messenger';

//The name of the database
define('DB_NAME', 'websysproject');



define( 'DB_HOST', 'localhost');

?>